var indexSectionsWithContent =
{
  0: "abcdefmprstv~",
  1: "f",
  2: "t",
  3: "efrst",
  4: "acfmpt~",
  5: "dv",
  6: "b"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Pages"
};

