var searchData=
[
  ['bibliography',['Bibliography',['../citelist.html',1,'']]]
];
