var searchData=
[
  ['bibliographic_20references',['Bibliographic References',['../citelist.html',1,'']]]
];
