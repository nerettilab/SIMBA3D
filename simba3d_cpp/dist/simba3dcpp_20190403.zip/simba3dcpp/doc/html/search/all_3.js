var searchData=
[
  ['dinner',['dinner',['../classtena_1_1feed__tena__dinner.html#a0353dcbea62b66caf8cae67cdb654015',1,'tena::feed_tena_dinner']]]
];
