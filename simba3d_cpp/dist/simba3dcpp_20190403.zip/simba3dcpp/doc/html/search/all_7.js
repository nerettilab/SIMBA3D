var searchData=
[
  ['print',['print',['../classtena_1_1feed__tena__dinner.html#a4980dd92a3d3d110a6d2d33812fe14d3',1,'tena::feed_tena_dinner']]],
  ['print_5fhelp_5fmenu',['print_help_menu',['../namespacetena.html#a9c9d5b51bb484d43a9a647ee9061318d',1,'tena']]],
  ['print_5fversion',['print_version',['../namespacetena.html#ab8af34a33232491fffc89e751046a76c',1,'tena']]]
];
