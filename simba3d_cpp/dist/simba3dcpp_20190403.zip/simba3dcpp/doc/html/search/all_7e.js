var searchData=
[
  ['_7efeed_5ftena_5fdinner',['~feed_tena_dinner',['../classtena_1_1feed__tena__dinner.html#ad00c875f73836975cdbbff696f788610',1,'tena::feed_tena_dinner']]]
];
