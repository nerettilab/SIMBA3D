cp ../../bin/programs/feed_tena .
