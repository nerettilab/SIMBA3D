./copybin.sh

./feed_tena -h > output.txt
./feed_tena -v >> output.txt
./feed_tena 1 2 3 >> output.txt
./feed_tena 1 2 hat >> output.txt
