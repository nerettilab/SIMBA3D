﻿
Template Name (TeNa) Library

This single concise sentence is the first thing that people will read when they first try to learn about the TeNa library; make it count.


=====
About
=====

Put a slightly more detailed description here. TeNa (pronounced "Tina!") is a template project layout to assist developers in standardizing best practices for DoD code development. It is not intended to be the 'rule of law' because nobody likes to be force fed anything. There are other ways of doing things, but this way isn't too bad.

I purposely put in many lame jokes in the documentation so that someone using the template will remove them and actually think about what they want to have in their documentation.

Whatever you decide to do with this template, it is my sincere hope that this will help you to make wonderfully organized projects that are a joy to collaboratively work on.


================
Directory Layout
================

- bin : directory for compiled binaries and executables

	- examples : directory for binaries of examples used to demonstrate use of library functions
	- scrap    : directory for binaries of scrap script used during development of code
	- tests    : directory for binaries of tests to verify outputs match theoretical expectations
	- programs : directory for binaries of main programs which are created using the C++ library
- data : directory for data files used by the library, tests, and examples
- doc  : directory for code documentation, theoretical writeups, and other supporting documentation
	- bibfile.bib : bibtex file for citations
- lib  : directory for external libraries 
	- lic : directory for 3rd pary licenses
- msvs - directory for Microsoft Visual Studio Project
- src  - directory for C++ source code
	- examples : directory for source code examples used to demonstrate use of library functions
	- scrap    : directory for source code scrap script used during development of code
	- tests    : directory for source code tests used to verify outputs match theoretical expectations
	- programs : directory for source code for main programs which are created using the C++ library
- tests    : directory for stand-alone data and test script examples
- compile.sh   : A shell script which will build the library using gcc
- Doxyfile   : Doxygen parameters file
- README.md  : The first thing a user is expected to read when looking into your library
- SConstruct : Scons construct file used to compile library	


============
Requirements
============

Required C++ Libraries include:
    - boost


=============
Documentation
=============

Automatically generated documentation for classes and functions have been constructed in the respective 'doc' sub-directories.

Examples which utilize the functions and classes can be seen in the 'examples' sub-directory. The relevant examples are linked in the auto-doc's.

Test script used to verify that the calculations are within acceptable tolerances can be seen in the 'test' sub-directory.


---------------------------------
Maintaining Doxygen Documentation
---------------------------------

![doxygen](../../data/logos/doxygen.png)

After modifying the source code, you may want to update the doxygen manual. To update the documentation, simply navigate to the main directory that contains the [Doxyfile](../../Doxyfile) file and use the script command:
\code{sh}
	doxygen
\endcode

Information about the project including it's name, version number, a brief discription, location of the project logo, and much much more can be edited in the [Doxyfile](../../Doxyfile). It is pretty self explanatory, but if you want more detail see the [doxygen manual](../../../doc/doxygen_manual-1.8.13.pdf) \cite DOXYGENMANUAL. Some things you may want to edit include:
	- PROJECT_NAME
	- PROJECT_NUMBER
	- PROJECT_BRIEF
	- PROJECT_LOGO

There are some logos in the data/logos directory, but you may want to put your own project logo elsewhere. Just make sure you use a relative (NOT ABSOLUTE) path.

See chapter 5 of the [doxygen manual](../../../doc/doxygen_manual-1.8.13.pdf) \cite DOXYGENMANUAL for details on how to use markdown in the source code.

Add bibtex bibliography references to the doc/bibfile.bib file to cite them within your source code.

You probably will want to edit the [README.md](../../README.md) file to match your project. Make sure you update the contact information so that Mr. Connor does not get a bunch a emails about your project.

===============
Version Control 
===============

As you make changes to the code your should update the PROJECT_NUMBER parameter with an appropriately enumerated version number in the [Doxyfile](../../Doxyfile). When a person reports a problem with your code, this will help you figure out if they have the latest version.

There are other ways you can enumerate versions. For example LaTeX versions by adding decimal points from the number \f$\pi\f$. I do not recommend you follow their example .

You may also keep track of things you want to work on using a todo list.


---------
Using git
---------

![git](../../data/logos/git.png)

To commit all the changes you made to the current branch (usually main) use the following command in an directory or sub-directory of the repository.
\code{sh}
git add --all :/
git commit .
\endcode
A commit message will be prompted in vim. The proper thing to do is give a brief one sentence description at the top of the commit message. Then add a space and write a slightly more detailed description of the changes you made (if you like). For example:

\verbatim
Consise one sentence description of commit changes

If you want to, put a more detailed description of commit changes made to the repository. It can be as verbose as you want. No one will ever fault you for providing a pedantic level of details here.
\endverbatim

I do not create, merge, or rollback repository branches very often. I usually forget how to do this when I need to. A good offline resource is the [git cheat sheet](../../../doc/github-git-cheat-sheet.pdf). 

I usually just edit the main branch, but this is very bad if you are working with multiple people and everyone just edits the main branch. Ideally, you should create a branch for any change except for minor changes that do not even require the code to be recompiled. If things do not work out, you can simply delete the branch or not merge it into the main branch.

-------
Updates (might be redundant because of git)
-------
- 05/12/2017 
	- scrap_experiment01 
	- Create something in the scrap directory
	- Make a main function in the scrap folder to as a preliminary developmental script.


----
Todo
----

- tena_function 
	- Create a function called tena
	- Document the code using doxygen as an example for other functions


=========
Compiling
=========

A shell script is provided [compile.sh](../../compile.sh) which will compile all the program files using gcc. This is shell script is literally the output generated from SCons.

To compile the source code using this script, simply navigate to the main directory that contains the [compile.sh](../../compile.sh) file and use the script command:
\code{sh}
	./compile.sh
\endcode

If the shell script does not have execute permissions use the script command:
\code{sh}
	chmod +x compile.sh
\endcode
Note that you should not add executre permissions without understanding what the script is doing.


You may wish to design your library so that it can be compiled for multiple systems. This can be challenging. There are several different ways you can do this. Here is what worked for me. I used SCons for compiling on Linux, and I created a Microsoft Visual Studio 2008 project to compile for Windows. You can use SCons on Windows too, you just need to tell it where the compiler is.

-----------
Using SCons
-----------

![SCons](../../data/logos/SCons.png)

To update the documentation, simply navigate to the main directory that contains the [SConstruct](../../SConstruct) file and use the script command:
\code{sh}
	scons
\endcode
Sometimes you can mess things up so that scons doesn't realize you made a change. You can clear out all the binaries and compiled objects using the following command:
\code{sh}
	scons --remove
\endcode

SCons allows you to specify complicated build instructions using python. The [SConstruct](../../SConstruct) file is a python script which tells SCons how to build the library and compile the source code.

The TeNa [SConstruct](../../SConstruct) file will recursively search through each object in the src directory and then compile and create binaries for each main function in the examples, programs, scrap, and tests subdirectories. The binaries will be outputed in their respective bin sub-directory. Unless you want to, you may not need to edit the [SConstruct](../../SConstruct) file as long as you agree with the directory layout for the src directory. 

Some reasons you may want to mess with the [SConstruct](../../SConstruct) file:
- you need to add links to external libraries
- you do not like the way the TeNa src directory is organized
- you do not want to exhaustively link your library
- you need to compile differently for different systems
- you want to learn how to use SCons hands on
- you want to be an individual and think for yourself

Do what you want/need to, but this works well for me.


-----------
Using CMake
-----------

I have never used CMake, but it is a cross-platform option with similiar capabilties to SCons. It has its own syntax that you will need to learn. I cannot tell you much more about it.


----------
Using MSVS
----------

It is possible to create a Microsoft Visual Studio Project so that its files are relatively located in the src directory. This way you will not need to maintain two sets of code. To pull this off, you will need to be careful because some standard library functions do not work correctly in Windows. For example, the quickSort function does not work correctly in MSVS2012. 

You can also use conditional macros which will detect the system you are on during the compilation.


===================
Contact Information
===================
![John Connor](../../data/logos/JohnConnor.jpg)
- Terminate John Connor
- <terminate.j.connor@skynet.mil>
- Code: T1000
- CYBERDYNE SYSTEMS
- +1 (555) 555-5555


