/**
* @file scrap_experiment01.cpp
* @brief An scrap script used to develop a code library.
*
* This scrap script doesn't do anything. It just serves as a template for 
* other scrap scripts. You may want to change the distribution statement.
*
* ======================
* DISTRIBUTION STATEMENT
* ======================
* Distribution Statement D. Distribution authorized to the Department of 
* Defense and U.S. DoD contractors only (CRITICAL TECHNOLOGY) (15 NOV 2016). 
* Other requests shall be referred to (CODE T1000 :  CYBERDYNE SYSTEMS).
*/


int main (){

}
